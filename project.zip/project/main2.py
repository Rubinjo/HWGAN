import numpy as np
import matplotlib.pyplot as plt
from emnist import extract_training_samples
from emnist import extract_test_samples
from split_data import loaddata
from GAN5 import GAN
import cv2

#variables
n_gans = []

def load_real_samples(value, value_next, value_previous):
    # load mnist dataset
    training_letter = []
    training_next_letter = []
    training_previours_letter = []

    train_set, test_set = loaddata()
    #all letters in dataset size 28*28
    if value_previous != 100:
        training_previours_letter = train_set[value_previous][0:96]

    if value_next != 100:   
        training_next_letter = train_set[value_next][0:96]
    
    training_letter = train_set[value][:]

    trainX = training_previours_letter + training_letter + training_next_letter
    #trainX = train_set[value][:]
    #trainX, labels_X = extract_training_samples('letters')
    
    #All digits in dataset
    #(trainX, _), (_, _) = load_data()
    
    # expand to 3d, e.g. add channels dimension
    X = np.expand_dims(trainX, axis=-1)
    # convert from unsigned ints to floats
    X = X.astype('float32')
    # scale from [0,255] to [0,1]
    X = X / 255
    return X


def split(word):
    return [char for char in word]



def Dofunction(value_next, value_previous, value, character):
    dataset = load_real_samples(value, value_next, value_previous)
        
    gan = GAN(num_epochs, Batch_size, dataset, character)
    # size of the latent space
    latent_dim = 100
    # create the discriminator
    d_model = gan.define_discriminator()
    print("Test1")
    # create the generator
    g_model = gan.define_generator(latent_dim)
    print("Test2")
    # create the gan
    gan_model = gan.define_gan(g_model, d_model)
    print("Test3")
    # train model
    gan.train(g_model, d_model, gan_model, latent_dim)
    print("Test4")
    
    #add gans in list to use a unkonwn number of letters
    n_gans.append(gan)
    print("Function is running")

if __name__=="__main__":
    # load image data
    Word = "et"
    letters = split(Word)

    #define parameters
    num_epochs = 40
    Batch_size = 128

    alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    alphabet_Capitals = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

    for i in range(0, len(letters)):
        next_letter_found = True
        previous_letter_found = True
        letter_found = True
        m,n,p = 0, 0, 0
        value_next = 0
        value_previous = 0
        while(letter_found):
            if(alphabet[p] == letters[i] or alphabet_Capitals[p] == letters[i]):
                letter_found = False
                value = p
            p+=1
            #print("Value of letter: ", value)
        if (i != len(letters)-1):
            next_letter = letters[i+1]
            while(next_letter_found):
                if (alphabet[m] == next_letter or alphabet_Capitals[m] == next_letter):
                    next_letter_found = False
                    value_next = m
                m+=1
            print("Value of next letter: ", value_next)
        else:
            value_next = 100


        if (i != 0):
            previous_letter = letters[i-1]
            while(previous_letter_found):
                if (alphabet[n] == previous_letter or alphabet_Capitals[n] == previous_letter):
                    previous_letter_found = False
                    value_previous = n 
                n+=1
            print("Value previous letter: ", value_previous)

        else:
            value_previous = 100 

        if (letters[i] == 'a' or letters[i] == 'A'):
            Dofunction(value_next, value_previous, value = 0,  character = 'a')
        elif (letters[i] == 'b' or letters[i] == 'B'):
            Dofunction(value_next, value_previous, value = 1, character = 'b')
        elif (letters[i] == 'c'  or letters[i] == 'Ç'):
            Dofunction(value_next, value_previous, value = 2, character = 'c')
        elif (letters[i] == 'd'  or letters[i] == 'D'):
            Dofunction(value_next, value_previous, value = 3, character = 'd')
        elif (letters[i] == 'e'  or letters[i] == 'E'):
            Dofunction(value_next, value_previous, value = 4, character = 'e')
        elif (letters[i] == 'f'  or letters[i] == 'F'):
            Dofunction(value_next, value_previous, value = 5, character = 'f')
        elif (letters[i] == 'g'  or letters[i] == 'G'):
            Dofunction(value_next, value_previous, value = 6, character = 'g')
        elif (letters[i] == 'h'  or letters[i] == 'H'):
            Dofunction(value_next, value_previous, value = 7, character = 'h')
        elif (letters[i] == 'i'  or letters[i] == 'I'):
            Dofunction(value_next, value_previous, value = 8, character = 'i')
        elif (letters[i] == 'j'  or letters[i] == 'J'):
            Dofunction(value_next, value_previous, value = 9, character = 'j')
        elif (letters[i] == 'k'  or letters[i] == 'K'):
            Dofunction(value_next, value_previous, value = 10, character = 'k')
        elif (letters[i] == 'l'  or letters[i] == 'L'):
            Dofunction(value_next, value_previous, value = 11, character = 'l')
        elif (letters[i] == 'm'  or letters[i] == 'M'):
            Dofunction(value_next, value_previous, value = 12, character = 'm')
        elif (letters[i] == 'n'  or letters[i] == 'N'):
            Dofunction(value_next, value_previous, value = 13, character = 'n')
        elif (letters[i] == 'o'  or letters[i] == 'O'):
            Dofunction(value_next, value_previous, value = 14, character = 'o')
        elif (letters[i] == 'p'  or letters[i] == 'P'):
            Dofunction(value_next, value_previous, value = 15, character = 'p')
        elif (letters[i] == 'q'  or letters[i] == 'Q'):
            Dofunction(value_next, value_previous, value = 16, character = 'q')
        elif (letters[i] == 'r'  or letters[i] == 'R'):
            Dofunction(value_next, value_previous, value = 17, character = 'r')
        elif (letters[i] == 's'  or letters[i] == 'S'):
            Dofunction(value_next, value_previous, value = 18, character = 's')
        elif (letters[i] == 't'  or letters[i] == 'T'):
            Dofunction(value_next, value_previous, value = 19, character = 't')
        elif (letters[i] == 'u'  or letters[i] == 'U'):
            Dofunction(value_next, value_previous, value = 20, character = 'u')
        elif (letters[i] == 'v'  or letters[i] == 'V'):
            Dofunction(value_next, value_previous, value = 21, character = 'v')
        elif (letters[i] == 'w'  or letters[i] == 'W'):
            Dofunction(value_next, value_previous, value = 22, character = 'w')
        elif (letters[i] == 'x'  or letters[i] == 'X'):
            Dofunction(value_next, value_previous, value = 23, character = 'x')
        elif (letters[i] == 'y'  or letters[i] == 'Y'):
            Dofunction(value_next, value_previous, value = 24, character = 'y')
        elif (letters[i] == 'z'  or letters[i] == 'Z'):
            Dofunction(value_next, value_previous, value = 25, character = 'z')
        else:
            print("No of all letters is matched!!")

    images = []
    for im in range(0, len(letters)):
        pathname = "out/generated_plot_%s.png" % (letters[im])
        load_im = cv2.imread(pathname)
        print(load_im.shape)
        im_cropped = load_im[60:420, 100:540]
        print(im_cropped.shape)
        images.append(im_cropped)

    for i in range(1, len(images)):
        im_h = images[i-1]
        images[i] = cv2.hconcat([im_h, images[i]])
        plt.imshow(images[i])

    plt.show()